# Måendekoll — installationsguide

## Vad du har fått
- `index.html` — sidan Linn använder varje dag. Fyra kategorier, tryck en färg per kategori, tryck "Spara". Klart.
- `historik.html` — sidan assistenterna använder för att se alla tidigare loggar, nyast överst. Ingen inmatning, bara läsning.

Båda sidorna delar samma databas (Firestore), så allt Linn sparar dyker upp direkt i historiken.

## Steg 1 — Skapa ett gratis Firebase-projekt
1. Gå till console.firebase.google.com och logga in med ett Google-konto.
2. Klicka "Add project", ge det ett namn (t.ex. maendekoll). Google Analytics behövs inte — stäng av det.

## Steg 2 — Aktivera databasen
1. I vänstermenyn: Build → Firestore Database → "Create database".
2. Välj "Start in test mode" för nu.
3. Välj en region nära Sverige, t.ex. europe-west1.

## Steg 3 — Hämta din konfiguration
1. Klicka på kugghjulet uppe till vänster → "Project settings".
2. Scrolla ner till "Your apps", klicka på webb-ikonen (</>) för att registrera en webbapp.
3. Ge den ett namn, klicka "Register app".
4. Du får upp ett `firebaseConfig`-objekt — kopiera hela det.

## Steg 4 — Klistra in configen
Öppna både `index.html` och `historik.html` i valfri textredigerare. Hitta raden:

```js
const firebaseConfig = {
  apiKey: "DIN_API_KEY",
  ...
};
```

Ersätt med din riktiga config från Steg 3. Gör det i BÅDA filerna (samma config i båda).

## Steg 5 — Säkrare regler (rekommenderas)
Test mode i Steg 2 gör databasen helt öppen i 30 dagar och stänger sedan av sig. Byt till detta istället, så fungerar det permanent:

1. Firestore Database → fliken "Rules".
2. Ersätt med:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /entries/{entry} {
      allow read: if true;
      allow create: if true;
      allow update, delete: if false;
    }
  }
}
```

3. Klicka "Publish".

Detta tillåter vem som helst med länken att skriva nya loggar och läsa historiken, men ingen kan ändra eller radera gamla loggar. Länken är inte sökbar eller offentligt listad någonstans, men den är heller inte lösenordsskyddad — dela den bara med Linn och assistenterna.

## Steg 6 — Lägg upp filerna
Enklast: GitHub Pages (gratis).
1. Skapa ett nytt repository på github.com, namnge det t.ex. maendekoll.
2. Ladda upp `index.html` och `historik.html`.
3. Settings → Pages → välj branch "main" och mapp "/ (root)" → Save.
4. Efter någon minut får du en länk som `dittnamn.github.io/maendekoll/` för Linns sida, och `dittnamn.github.io/maendekoll/historik.html` för assistenternas historiksida.

## Steg 7 — Gör den lätt att använda
- Skicka länken till Linn, be henne öppna den i telefonens webbläsare och välja "Lägg till på hemskärmen" — då blir det en app-ikon hon trycker på, precis som vilken app som helst.
- Skicka historik-länken till assistenterna i gruppchatten.

## Kostnad
Firebase Firestore gratisnivå (Spark-planen) inkluderar 50 000 läsningar och 20 000 skrivningar per dag, helt gratis, inget kreditkort krävs. En daglig måendekoll av en person, läst av några assistenter, ligger enormt långt under det. Realistisk kostnad: **0 kr**.
